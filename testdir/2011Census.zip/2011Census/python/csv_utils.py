import csv
import sys
import common_utils



def get_column_desc(csvfilepath):
	columnType = []
	columnLength = []
	columnName = []
	with open(csvfilepath,'rb') as csvfile:
		spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
		headerRow = None
		counter = 0


		for row in spamreader:
			counter = counter + 1
			if counter == 1:
				headerRow = row
				#print headerRow
				for cell in row:
					columnType.append('double')
					columnLength.append(0)
				continue
			cellCounter=0
			for cell in row:
				#print cell
				if not common_utils.is_number(cell):
					columnType[cellCounter] = 'varchar'
					if cellCounter == 3:
						sys.exit(1)
					if len(cell) > columnLength[cellCounter]:
						columnLength[cellCounter] = len(cell)
				cellCounter = cellCounter + 1
			#print '\n'
			


	for cell in headerRow:
		columnName.append(cell.replace(' ','_').upper())

	#for cell in columnType:
	#	print cell

	#for cell in columnLength:
	#	print cell

	return columnName, columnType, columnLength




