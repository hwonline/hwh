import csv
import sys
import db_utils
import csv_utils


def load_csv_data(csvfilepath, connection, tableName):
	columnName, columnType, columnLength = csv_utils.get_column_desc(csvfilepath)

	numberOfColumns = len(columnName)
	insertTemplate = """ INSERT INTO %s (""" % tableName
	values = "VALUES ("
	for i in range(0,numberOfColumns):
		name = columnName[i]
		colType = columnType[i]
		insertTemplate = insertTemplate + name + ","
	insertTemplate = insertTemplate[:-1]
	insertTemplate = insertTemplate + ") " 


	with open(csvfilepath,'rb') as csvfile:
		spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
		headerRow = None
		counter = 0
		cursor = connection.cursor()
		for row in spamreader:
			counter = counter + 1
			if counter == 1:
				continue
			cellCounter=0
			values = " VALUES ("
			for cell in row:
				cell = cell.replace("'", "\\'")
				if columnType[cellCounter] == 'varchar':
					# insert varchar data
					values = values + "'%s'," % cell
				else:
					# insert double data
					values = values + "%s," % cell
				cellCounter = cellCounter + 1
			# remove the last comma
			values = values[:-1] + ");"
			insertSql = insertTemplate + values
			#print insertSql
			cursor.execute(insertSql)
		connection.commit()
		cursor.close()