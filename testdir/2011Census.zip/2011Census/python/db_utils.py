import mysql.connector

config = {
  'user': 'root',
  'password': 'Louis15',
  'host': '127.0.0.1',
  'database': 'dbcensus'
}

def get_db_connection():
	cnx = mysql.connector.connect(**config)
	return cnx

def get_db_cursor():
	cnx = mysql.connector.connect(**config)
	cursor = cnx.cursor(buffered=True)
	return cursor

def create_table(connection, tableName,tableHeader, headerType, maxLength):
	createTableSql= "CREATE TABLE `" + tableName+ "` ("
	cellCounter = 0
	for cell in headerType:
		if cell == 'varchar':
			createTableSql = createTableSql + "`"+ tableHeader[cellCounter].replace(' ','_').upper() +"` "+ cell + "("+str(maxLength[cellCounter])+"),"
		else:
			createTableSql = createTableSql + "`"+ tableHeader[cellCounter].replace(' ','_').upper() +"` "+ cell +","
		cellCounter = cellCounter + 1
	createTableSql = createTableSql[:-1]
	createTableSql = createTableSql +")"

	cursor = connection.cursor()
	
	# Drop table if it already exist using execute() method.
	cursor.execute("DROP TABLE IF EXISTS "+tableName)

	#print createTableSql
	cursor.execute(createTableSql)
	cursor.close()
