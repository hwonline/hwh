import csv
import sys
import db_utils
import csv_utils
import csv_load_utils
import csv_table_mappings


root = '/appvol/owendata/australia/2011Census/TimeSeriesShortHeading/ALL/2011 Census TSP All Geographies for AUST'
csvTableMappings = csv_table_mappings.get_csv_table_mappings(root)

csvTableMappings.append(('CENSUS_GEOG_DESC','./data_import_workspace/Census_geog_desc.csv'))


connection = db_utils.get_db_connection()
for (tableName,csvfilepath) in csvTableMappings:	
	columnName, columnType, columnLength = csv_utils.get_column_desc(csvfilepath)

	print "create table '%s'" % tableName
	db_utils.create_table(connection, tableName, columnName, columnType, columnLength)
	print "create table '%s' -- completed OK" % tableName

	print "load csv file %s to table '%s'" % (csvfilepath,tableName)
	csv_load_utils.load_csv_data(csvfilepath, connection, tableName)
	print "load csv file %s to table '%s' -- completed OK" % (csvfilepath,tableName)

connection.close()

