
-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: 
-- Input Parameters
--    col01 C01_1_199_CF_T 
--    col02 C01_200_399_CF_T
--    col03 C01_400_599_CF_T 
--    col04 C01_600_799_CF_T 
--    col05 C01_800_999_CF_T  
--    col06 C01_1000_1499_CF_T  
--    col07 C01_1500_1999_CF_T 
--    col08 C01_2000_2499_CF_T 
--    col09 C01_2500_2999_CF_T 
--    col10 C01_3000m_CF_T
--  return medium income
-- --------------------------------------------------------------------------------
DELIMITER $$


CREATE FUNCTION `MediumIncome` (
col01 double, 
col02 double, 
col03 double, 
col04 double, 
col05 double, 
col06 double, 
col07 double, 
col08 double, 
col09 double, 
col10 double
)
RETURNS double
BEGIN
    DECLARE mediumIncome double;
	DECLARE total integer;
	DECLARE mediumNumber integer;
	DECLARE subTotalStart integer;
	DECLARE subTotalEnd integer;
	DECLARE incomeStart double;
	DECLARE incomeEnd double;
	select col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 + col10 into total;
	select total/2 into mediumNumber;
	if mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09;
		set subTotalEnd = total;
		set incomeStart = 3000;
		set incomeEnd = 4000;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 ;
		set incomeStart = 2500;
		set incomeEnd = 2999;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07  then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 ;
		set incomeStart = 2000;
		set incomeEnd = 2499;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06  then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 ;
		set incomeStart = 1500;
		set incomeEnd = 1999;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);

	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 + col06 ;
		set incomeStart = 1000;
		set incomeEnd = 1499;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);

	elseif mediumNumber > col01 + col02 + col03 + col04 then
		set subTotalStart = col01 + col02 + col03 + col04 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 ;
		set incomeStart = 800;
		set incomeEnd = 999;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);

	elseif mediumNumber > col01 + col02 + col03 then
		set subTotalStart = col01 + col02 + col03 ;
		set subTotalEnd = col01 + col02 + col03 + col04 ;
		set incomeStart = 600;
		set incomeEnd = 799;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);

	elseif mediumNumber > col01 + col02  then
		set subTotalStart = col01 + col02 ;
		set subTotalEnd = col01 + col02 + col03 ;
		set incomeStart = 400;
		set incomeEnd = 599;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);

	elseif mediumNumber > col01  then
		set subTotalStart = col01 ;
		set subTotalEnd = col01 + col02 ;
		set incomeStart = 200;
		set incomeEnd = 399;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);
	else 
		set subTotalStart = 0 ;
		set subTotalEnd = col01;
		set incomeStart = 1;
		set incomeEnd = 199;
		set mediumIncome= incomeStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (incomeEnd-incomeStart);
	end if;

 RETURN (mediumIncome);
END
