

LGA level




# how many LGAs' population growth is more than 5% from 2006 to 2011
# result: 266
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P as C06_INCREASE, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P as C11_INCREASE 
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
where (Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P > 0.05

# how many LGAs' population growth is more than 5% both from 2001 to 2006 and 2006 to 2011
# result: 131
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P as C06_INCREASE, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P as C11_INCREASE 
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
where (Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P > 0.05
and (Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P >0.05
order by C11_INCREASE desc 




# how many LGAs' population is more than 10,000 
# result: 303
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P  
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
where Tot_persons_C11_P > 10000



# how many LGAs' population is more than 10,000 and population growth is more than 5% from 2006 to 2011
# result: 174
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P as C06_INCREASE, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P as C11_INCREASE 
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
where 
Tot_persons_C11_P > 10000 
and (Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P > 0.05
order by C11_INCREASE desc 

# how many LGAs' population is more than 10,000 and population growth is more than 5% both from 2001 to 2006 and 2006 to 2011
# result: 106
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P as C06_INCREASE, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P as C11_INCREASE 
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
where 
Tot_persons_C11_P > 10000
and (Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P > 0.05
and (Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P >0.05
order by C11_INCREASE desc 




# medium rent of the LGAs' population is more than 10,000 and population growth is more than 5% from 2006 to 2011
select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P as C06_POP_INCREASE, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P as C11_POP_INCREASE,
MediumRent(C01_0_74_Tot, C01_75_99_Tot, C01_100_149_Tot, C01_150_199_Tot, C01_200_224_Tot, C01_225_274_Tot, 
	C01_275_349_Tot, C01_350_449_Tot, C01_450_549_Tot, C01_550_649_Tot, C01_650_over_Tot) as C01_MEDIUM_RENT,
MediumRent(C06_0_74_Tot, C06_75_99_Tot, C06_100_149_Tot, C06_150_199_Tot, C06_200_224_Tot, C06_225_274_Tot, 
	C06_275_349_Tot, C06_350_449_Tot, C06_450_549_Tot, C06_550_649_Tot, C06_650_over_Tot) as C06_MEDIUM_RENT,
MediumRent(C11_0_74_Tot, C11_75_99_Tot, C11_100_149_Tot, C11_150_199_Tot, C11_200_224_Tot, C11_225_274_Tot, 
	C11_275_349_Tot, C11_350_449_Tot, C11_450_549_Tot, C11_550_649_Tot, C11_650_over_Tot) as C11_MEDIUM_RENT,
MediumIncome(C01_1_199_CF_T, C01_200_399_CF_T,C01_400_599_CF_T,C01_600_799_CF_T,C01_800_999_CF_T, 
C01_1000_1499_CF_T, C01_1500_1999_CF_T, C01_2000_2499_CF_T, C01_2500_2999_CF_T, C01_3000m_CF_T) as C01_MEDIUM_INCOME,
MediumIncome(C06_1_199_CF_T, C06_200_399_CF_T,C06_400_599_CF_T,C06_600_799_CF_T,C06_800_999_CF_T, 
C06_1000_1499_CF_T, C06_1500_1999_CF_T, C06_2000_2499_CF_T, C06_2500_2999_CF_T, C06_3000m_CF_T) as C06_MEDIUM_INCOME,
MediumIncome(C11_1_199_CF_T, C11_200_399_CF_T,C11_400_599_CF_T,C11_600_799_CF_T,C11_800_999_CF_T, 
C11_1000_1499_CF_T, C11_1500_1999_CF_T, C11_2000_2499_CF_T, C11_2500_2999_CF_T, C11_3000m_CF_T) as C11_MEDIUM_INCOME
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code
left join LGA_T19A c on a.region_id = c.region_id
left join LGA_T19B d on a.region_id = d.region_id
left join LGA_T22A e on a.region_id = e.region_id
left join LGA_T22B f on a.region_id = f.region_id
where 
Tot_persons_C11_P > 10000
and (Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P > 0.05
and (Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P >0.05
order by C11_POP_INCREASE desc 











select a.region_id, b.Label,Tot_persons_C01_P,Tot_persons_C06_P,Tot_persons_C11_P, 
(Tot_persons_C06_P-Tot_persons_C01_P)/Tot_persons_C01_P, 
(Tot_persons_C11_P-Tot_persons_C06_P)/Tot_persons_C06_P  
from LGA_T01 a left join CENSUS_GEOG_DESC b on a.region_id = b.code




