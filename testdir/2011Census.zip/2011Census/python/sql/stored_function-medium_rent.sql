
-- --------------------------------------------------------------------------------
-- Routine DDL
-- Note: 
-- Input Parameters
--    col01 C11_0_74_Tot 
--    col02 C11_75_99_Tot
--    col03 C11_100_149_Tot 
--    col04 C11_150_199_Tot 
--    col05 C11_200_224_Tot  
--    col06 C11_225_274_Tot  
--    col07 C11_275_349_Tot 
--    col08 C11_350_449_Tot 
--    col09 C11_450_549_Tot 
--    col10 C11_550_649_Tot 
--    col11 C11_650_over_Tot
--  return medium rent
-- --------------------------------------------------------------------------------
DELIMITER $$


CREATE FUNCTION `MediumRent` (
col01 double, 
col02 double, 
col03 double, 
col04 double, 
col05 double, 
col06 double, 
col07 double, 
col08 double, 
col09 double, 
col10 double, 
col11 double
)
RETURNS double
BEGIN
    DECLARE mediumRent double;
	DECLARE total integer;
	DECLARE mediumNumber integer;
	DECLARE subTotalStart integer;
	DECLARE subTotalEnd integer;
	DECLARE rentStart double;
	DECLARE rentEnd double;
	select col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 + col10 + col11 into total;
	select total/2 into mediumNumber;
	if mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 + col10 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 + col10;
		set subTotalEnd = total;
		set rentStart = 650;
		set rentEnd = 800;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09 + col10;
		set rentStart = 550;
		set rentEnd = 649;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 ;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08 + col09;
		set rentStart = 450;
		set rentEnd = 549;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);
	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 +
			col06 + col07 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +
			col06 + col07;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 +
			col06 + col07 + col08;
		set rentStart = 350;
		set rentEnd = 449;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 + col06 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05 +	col06;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 + col06 + col07;
		set rentStart = 275;
		set rentEnd = 349;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	elseif mediumNumber > col01 + col02 + col03 + col04 + col05 then
		set subTotalStart = col01 + col02 + col03 + col04 + col05;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05 + col06;
		set rentStart = 225;
		set rentEnd = 274;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	elseif mediumNumber > col01 + col02 + col03 + col04 then
		set subTotalStart = col01 + col02 + col03 + col04;
		set subTotalEnd = col01 + col02 + col03 + col04 + col05;
		set rentStart = 200;
		set rentEnd = 224;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	elseif mediumNumber > col01 + col02 + col03 then
		set subTotalStart = col01 + col02 + col03;
		set subTotalEnd = col01 + col02 + col03 + col04;
		set rentStart = 150;
		set rentEnd = 199;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	elseif mediumNumber > col01 + col02 then
		set subTotalStart = col01 + col02;
		set subTotalEnd = col01 + col02 + col03;
		set rentStart = 100;
		set rentEnd = 149;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);
	elseif mediumNumber > col01 then
		set subTotalStart = col01 ;
		set subTotalEnd = col01 + col02;
		set rentStart = 75;
		set rentEnd = 99;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);

	else
		set subTotalStart = 0;
		set subTotalEnd = col01;
		set rentStart = 0;
		set rentEnd = 74;
		set mediumRent= rentStart + (mediumNumber - subTotalStart)/(subTotalEnd - subTotalStart) * (rentEnd-rentStart);
	end if;

 RETURN (mediumRent);
END
