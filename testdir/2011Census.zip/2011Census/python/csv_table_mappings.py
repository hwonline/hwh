import os

def get_csv_table_mappings(root):
	csvTableMappings=[]
	for name in os.listdir(root):
		#print name
		tableName= name
		if name == 'AUST':
			full_path = os.path.join(root, name)
		else:
			full_path = os.path.join(root, name)
			full_path = os.path.join(full_path, 'AUST')
		for file_name in os.listdir(full_path):
			full_path1 = os.path.join(full_path, file_name)
			if os.path.isfile(full_path1):
				tableName1 = tableName + '_' + file_name.split('_')[1]
				#print tableName1
				#print full_path1
				csvTableMappings.append((tableName1,full_path1))


	#for (tableName, full_path) in csvTableMappings:
	#	print tableName
	#	print full_path
	return csvTableMappings
